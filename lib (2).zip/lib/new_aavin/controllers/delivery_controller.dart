import 'package:get/get.dart';
import 'package:url_launcher/url_launcher.dart';
import '../models/delivery_model.dart';
import '../screens/delivery_points_screen.dart';
import '../screens/store_details_screen.dart';

enum AppMode {
  delivery,
  collection,
}

class DeliveryController extends GetxController {

  var name = "Rajesh Kumar".obs;
  var vehicleNumber = "TN22CB2871".obs;

  var appMode = AppMode.delivery.obs;

  /// TRACK CURRENT STORE (FOR COLLECTION)
  var currentCollectingIndex = 0.obs;

  var deliveries = <DeliveryModel>[

    DeliveryModel(
      number: "01",
      storeName: "Balaji Stores",
      address: "No.21 AA Block 3rd St, Anna Nagar",
      status: DeliveryStatus.delivered,
      products: [
        ProductModel(name: "Milk (250ml)", trays: 8, packets: 12, tubs: 0),
        ProductModel(name: "Milk (500ml)", trays: 10, packets: 9, tubs: 0),
        ProductModel(name: "Curd (500ml)", trays: 4, packets: 5, tubs: 4),
      ],
    ),

    DeliveryModel(
      number: "02",
      storeName: "Sivanesh Stores",
      address: "No.21 AA Block 3rd St, Anna Nagar",
      status: DeliveryStatus.delivering,
      products: [
        ProductModel(name: "Milk (250ml)", trays: 6, packets: 9, tubs: 0),
        ProductModel(name: "Milk (500ml)", trays: 8, packets: 0, tubs: 4),
        ProductModel(name: "Curd (500ml)", trays: 2, packets: 0, tubs: 5),
      ],
    ),

    DeliveryModel(
      number: "03",
      storeName: "Kishore Stall",
      address: "No.21 AA Block 3rd St, Anna Nagar",
      status: DeliveryStatus.pending,
      products: [
        ProductModel(name: "Milk (250ml)", trays: 5, packets: 6, tubs: 0),
        ProductModel(name: "Milk (500ml)", trays: 6, packets: 3, tubs: 0),
      ],
    ),

    DeliveryModel(
      number: "04",
      storeName: "Murugan Stores",
      address: "No.21 AA Block 3rd St, Anna Nagar",
      status: DeliveryStatus.pending,
      products: [
        ProductModel(name: "Milk (250ml)", trays: 7, packets: 10, tubs: 2),
        ProductModel(name: "Milk (500ml)", trays: 9, packets: 0, tubs: 0),
        ProductModel(name: "Curd (500ml)", trays: 3, packets: 6, tubs: 0),
      ],
    ),

    DeliveryModel(
      number: "05",
      storeName: "Lakshmi Dairy Store",
      address: "12 Market Road, T. Nagar",
      status: DeliveryStatus.pending,
      products: [
        ProductModel(name: "Milk (250ml)", trays: 5, packets: 8, tubs: 1),
        ProductModel(name: "Milk (500ml)", trays: 7, packets: 0, tubs: 0),
        ProductModel(name: "Curd (500ml)", trays: 4, packets: 5, tubs: 0),
      ],
    ),

    DeliveryModel(
      number: "06",
      storeName: "Sri Balaji Milk Center",
      address: "45 Gandhi Road, Velachery",
      status: DeliveryStatus.pending,
      products: [
        ProductModel(name: "Milk (250ml)", trays: 8, packets: 12, tubs: 2),
        ProductModel(name: "Milk (500ml)", trays: 6, packets: 0, tubs: 0),
        ProductModel(name: "Curd (500ml)", trays: 5, packets: 4, tubs: 1),
      ],
    ),

  ].obs;

  // ================== START COLLECTION ==================
  void startCollection() {
    appMode.value = AppMode.collection;

    /// reverse order (last delivered first collected)
    deliveries.value = deliveries.reversed.toList();

    /// reset index
    currentCollectingIndex.value = 0;
  }

  // ================== NAVIGATION ==================
  void openStoreDetails(DeliveryModel store) {
    Get.to(
          () => const StoreDetailsScreen(),
      arguments: store,
    );
  }

  // ================== DELIVERY ==================
  void markDeliveredAndGoBack(DeliveryModel store) {

    store.status = DeliveryStatus.delivered;

    int index = deliveries.indexOf(store);

    /// move to next delivery
    if (index < deliveries.length - 1) {
      deliveries[index + 1].status = DeliveryStatus.delivering;
    }

    deliveries.refresh();

    Get.snackbar(
      "Success",
      "${store.storeName} marked as delivered",
      snackPosition: SnackPosition.BOTTOM,
    );

    Get.off(() => const DeliveryPointsScreen());
  }

  // ================== COLLECTION ==================
  void markCollectedAndGoBack(
      DeliveryModel store,
      int trays,
      int tubs,
      ) {

    /// ✅ SAVE INPUT DATA
    store.collectedTrays = trays;
    store.collectedTubs = tubs;

    int index = deliveries.indexOf(store);

    /// ✅ AUTO MOVE NEXT
    if (index < deliveries.length - 1) {
      currentCollectingIndex.value = index + 1;
    } else {

      /// ALL COLLECTION DONE
      appMode.value = AppMode.delivery;

      Get.snackbar(
        "Completed",
        "All collections finished",
        snackPosition: SnackPosition.BOTTOM,
      );
    }

    deliveries.refresh();

    Get.off(() => const DeliveryPointsScreen());
  }

  // ================== MAP ==================
  void openMap() async {
    final url = Uri.parse(
      "https://www.google.com/maps/search/?api=1&query=Anna+Nagar",
    );

    if (await canLaunchUrl(url)) {
      await launchUrl(url);
    }
  }
}
