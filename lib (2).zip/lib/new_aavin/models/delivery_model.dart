enum DeliveryStatus {
  delivered,
  delivering,
  pending,
}

class ProductModel {
  String name;
  int trays;
  int packets;
  int tubs;

  ProductModel({
    required this.name,
    required this.trays,
    required this.packets,
    required this.tubs,
  });
}

class DeliveryModel {
  String number;
  String storeName;
  String address;
  DeliveryStatus status;
  List<ProductModel> products;

  /// ✅ COLLECTION DATA
  int collectedTrays;
  int collectedTubs;

  DeliveryModel({
    required this.number,
    required this.storeName,
    required this.address,
    required this.status,
    required this.products,
    this.collectedTrays = 0,
    this.collectedTubs = 0,
  });

  /// ✅ TOTAL CALCULATIONS (VERY USEFUL)
  int get totalTrays =>
      products.fold(0, (sum, item) => sum + item.trays);

  int get totalPackets =>
      products.fold(0, (sum, item) => sum + item.packets);

  int get totalTubs =>
      products.fold(0, (sum, item) => sum + item.tubs);

  /// ✅ REMAINING (USED IN UI)
  int get remainingTrays => totalTrays - collectedTrays;

  int get remainingTubs => totalTubs - collectedTubs;

  /// ✅ CHECK STATUS
  bool get isFullyCollected =>
      collectedTrays >= totalTrays &&
          collectedTubs >= totalTubs;
}
