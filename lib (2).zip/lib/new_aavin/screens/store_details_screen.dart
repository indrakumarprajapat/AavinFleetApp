import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:get/get.dart';
import '../controllers/delivery_controller.dart';
import '../models/delivery_model.dart';

class StoreDetailsScreen extends GetView<DeliveryController> {
  const StoreDetailsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final DeliveryModel? store = Get.arguments;

    if (store == null) {
      return const Scaffold(
        body: Center(child: Text("Store data not found")),
      );
    }

    /// ✅ USING MODEL HELPERS
    final int totalTrays = store.totalTrays;
    final int totalPackets = store.totalPackets;
    final int totalTubs = store.totalTubs;

    /// CONTROLLERS (pre-filled)
    final TextEditingController collectedTraysController =
    TextEditingController(text: store.collectedTrays.toString());

    final TextEditingController collectedTubsController =
    TextEditingController(text: store.collectedTubs.toString());

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: Text(store.storeName),
        centerTitle: true,
        backgroundColor: const Color(0xff1BA6C8),
      ),
      body: Obx(() {
        final isCollection =
            controller.appMode.value == AppMode.collection;

        return SingleChildScrollView(
          padding: const EdgeInsets.only(bottom: 40),
          child: Column(
            children: [

              /// HEADER
              Stack(
                children: [
                  SvgPicture.asset(
                    "assets/images/Vector.svg",
                    height: 220,
                    width: double.infinity,
                    color: const Color(0xff1BA6C8),
                    fit: BoxFit.fill,
                  ),
                  Positioned(
                    top: 50,
                    left: 0,
                    right: 0,
                    child: Image.asset(
                      "assets/images/app_icon_namakkal.png",
                      height: 50,
                    ),
                  ),
                ],
              ),

              const SizedBox(height: 16),

              /// STORE INFO CARD
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Card(
                  elevation: 2,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16),
                    side: BorderSide(color: Colors.blue.shade200),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Row(
                      children: [
                        Container(
                          height: 70,
                          width: 70,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(12),
                            color: Colors.blue.shade50,
                          ),
                          child: const Icon(
                            Icons.store,
                            size: 35,
                            color: Colors.blue,
                          ),
                        ),
                        const SizedBox(width: 15),
                        Expanded(
                          child: Column(
                            crossAxisAlignment:
                            CrossAxisAlignment.start,
                            children: [
                              Text(
                                store.storeName,
                                style: const TextStyle(
                                  fontSize: 22,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              const SizedBox(height: 4),
                              Text(
                                store.address,
                                style: const TextStyle(
                                    color: Colors.grey),
                              ),
                              const SizedBox(height: 6),
                              Text(
                                "ID: ${store.number}",
                                style: const TextStyle(
                                  color: Colors.blue,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),

              const SizedBox(height: 20),

              /// ================= DELIVERY MODE =================
              if (!isCollection) ...[

                const Padding(
                  padding: EdgeInsets.symmetric(horizontal: 16),
                  child: Row(
                    children: [
                      Expanded(
                          flex: 3,
                          child: Text("Item",
                              style: TextStyle(
                                  fontWeight:
                                  FontWeight.bold))),
                      Expanded(
                          child: Text("Tray",
                              textAlign: TextAlign.center)),
                      Expanded(
                          child: Text("Packet",
                              textAlign: TextAlign.center)),
                      Expanded(
                          child: Text("Tub",
                              textAlign: TextAlign.center)),
                    ],
                  ),
                ),

                const SizedBox(height: 10),

                ...store.products.map((product) {
                  return Padding(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 16, vertical: 8),
                    child: Row(
                      children: [
                        Expanded(
                            flex: 3,
                            child: Text(product.name)),
                        Expanded(
                            child: Text("${product.trays}",
                                textAlign:
                                TextAlign.center)),
                        Expanded(
                            child: Text("${product.packets}",
                                textAlign:
                                TextAlign.center)),
                        Expanded(
                            child: Text("${product.tubs}",
                                textAlign:
                                TextAlign.center)),
                      ],
                    ),
                  );
                }),

                const SizedBox(height: 10),

                /// TOTAL
                Padding(
                  padding:
                  const EdgeInsets.symmetric(horizontal: 16),
                  child: Row(
                    children: [
                      const Expanded(
                        flex: 3,
                        child: Text("Total",
                            style: TextStyle(
                                fontWeight:
                                FontWeight.bold)),
                      ),
                      Expanded(
                          child: Text("$totalTrays",
                              textAlign: TextAlign.center)),
                      Expanded(
                          child: Text("$totalPackets",
                              textAlign: TextAlign.center)),
                      Expanded(
                          child: Text("$totalTubs",
                              textAlign: TextAlign.center)),
                    ],
                  ),
                ),

                const SizedBox(height: 25),

                /// BUTTONS
                Padding(
                  padding:
                  const EdgeInsets.symmetric(horizontal: 16),
                  child: ElevatedButton(
                    onPressed: controller.openMap,
                    child: const Text("Get Directions"),
                  ),
                ),

                const SizedBox(height: 10),

                Padding(
                  padding:
                  const EdgeInsets.symmetric(horizontal: 16),
                  child: ElevatedButton(
                    onPressed: () =>
                        controller.markDeliveredAndGoBack(store),
                    child: const Text("Mark Delivered"),
                  ),
                ),
              ],

              /// ================= COLLECTION MODE =================
              if (isCollection) ...[

                /// TOTAL + PROGRESS
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: Colors.blue.shade100,
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Column(
                      children: [
                        Text(
                          "Trays: ${store.collectedTrays}/$totalTrays | "
                              "Tubs: ${store.collectedTubs}/$totalTubs",
                          style: const TextStyle(
                              fontWeight: FontWeight.bold),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          "Remaining: ${store.remainingTrays} trays, "
                              "${store.remainingTubs} tubs",
                        ),
                      ],
                    ),
                  ),
                ),

                const SizedBox(height: 20),

                /// INPUT
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: Column(
                    children: [
                      TextField(
                        controller: collectedTraysController,
                        keyboardType: TextInputType.number,
                        decoration: const InputDecoration(
                          labelText: "Collected Trays",
                          border: OutlineInputBorder(),
                        ),
                      ),
                      const SizedBox(height: 16),
                      TextField(
                        controller: collectedTubsController,
                        keyboardType: TextInputType.number,
                        decoration: const InputDecoration(
                          labelText: "Collected Tubs",
                          border: OutlineInputBorder(),
                        ),
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 25),

                /// BUTTON
                Padding(
                  padding:
                  const EdgeInsets.symmetric(horizontal: 16),
                  child: ElevatedButton(
                    onPressed: () {
                      final trays =
                          int.tryParse(collectedTraysController.text) ?? 0;

                      final tubs =
                          int.tryParse(collectedTubsController.text) ?? 0;

                      controller.markCollectedAndGoBack(
                        store,
                        trays,
                        tubs,
                      );
                    },
                    child: const Text("Mark Collected"),
                  ),
                ),
              ],
            ],
          ),
        );
      }),
    );
  }
}
