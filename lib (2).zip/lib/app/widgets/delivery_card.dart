import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../new_aavin/controllers/delivery_controller.dart';
import '../../new_aavin/models/delivery_model.dart';

class DeliveryCard extends StatelessWidget {
  final String number;
  final String storeName;
  final String address;

  final int tray;
  final int packet;
  final int tub;

  final DeliveryStatus status;

  /// ✅ NEW (for collection mode)
  final int? remainingTray;
  final int? remainingTub;
  final bool isCollection;

  const DeliveryCard({
    super.key,
    required this.number,
    required this.storeName,
    required this.address,
    required this.status,
    required this.tray,
    required this.packet,
    required this.tub,
    this.remainingTray,
    this.remainingTub,
    this.isCollection = false,
  });

  bool get isDelivered => status == DeliveryStatus.delivered;
  bool get isCurrent => status == DeliveryStatus.delivering;

  Color getStatusColor() {
    switch (status) {
      case DeliveryStatus.delivered:
        return Colors.green;
      case DeliveryStatus.delivering:
        return Colors.blue;
      case DeliveryStatus.pending:
        return Colors.grey;
    }
  }

  String getStatusText() {
    /// ✅ CHANGE ONLY TEXT IN COLLECTION MODE
    if (isCollection) {
      switch (status) {
        case DeliveryStatus.delivered:
          return "Collected";
        case DeliveryStatus.delivering:
          return "Collecting";
        case DeliveryStatus.pending:
          return "To Be Collected";
      }
    }

    /// DEFAULT DELIVERY MODE
    switch (status) {
      case DeliveryStatus.delivered:
        return "Delivered";
      case DeliveryStatus.delivering:
        return "To Deliver";
      case DeliveryStatus.pending:
        return "Pending";
    }
  }

  Color getCardColor() {
    if (status == DeliveryStatus.delivering) return Colors.blue.shade50;
    if (status == DeliveryStatus.pending) return Colors.grey.shade200;
    return Colors.white;
  }

  @override
  Widget build(BuildContext context) {
    final controller = Get.find<DeliveryController>();

    return GestureDetector(
      onTap: () {
        final store = controller.deliveries.firstWhere(
              (element) => element.number == number,
        );

        controller.openStoreDetails(store);
      },
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: getCardColor(),
          borderRadius: BorderRadius.circular(16),
          border: isCurrent ? Border.all(color: Colors.blue, width: 1.5) : null,
          boxShadow: const [
            BoxShadow(color: Colors.black26, blurRadius: 6),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [

            /// TOP ROW (UNCHANGED)
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  height: 60,
                  width: 60,
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    color: getStatusColor(),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Text(
                    number,
                    style: const TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                      fontSize: 28,
                    ),
                  ),
                ),

                const SizedBox(width: 12),

                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Expanded(
                            child: Text(
                              storeName,
                              style: const TextStyle(
                                fontWeight: FontWeight.bold,
                                fontSize: 22,
                              ),
                            ),
                          ),
                          Container(
                            height: 26,
                            width: 26,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: isDelivered
                                  ? Colors.green
                                  : Colors.grey.shade300,
                            ),
                            child: Icon(
                              Icons.check,
                              size: 18,
                              color: isDelivered ? Colors.white : Colors.grey,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 4),
                      Text(
                        address,
                        style: const TextStyle(color: Colors.grey),
                      ),
                    ],
                  ),
                ),
              ],
            ),

            const SizedBox(height: 14),
            Divider(color: Colors.grey.shade300),
            const SizedBox(height: 14),

            /// DATA SECTION
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [

                /// TITLE CHANGE
                Row(
                  children: [
                    Icon(
                      Icons.local_shipping,
                      size: 18,
                      color: (isDelivered || isCurrent)
                          ? Colors.blue
                          : Colors.grey,
                    ),
                    const SizedBox(width: 6),
                    Text(
                      isCollection ? "Collection" : "Delivery",
                      style: TextStyle(
                        color: !isDelivered && !isCurrent
                            ? Colors.grey
                            : Colors.black,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ],
                ),

                const SizedBox(height: 12),

                /// TRAY
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(
                      children: [
                        Icon(Icons.inventory, size: 18,
                            color: (isDelivered || isCurrent)
                                ? Colors.orangeAccent
                                : Colors.grey),
                        const SizedBox(width: 6),
                        const Text("Tray"),
                      ],
                    ),
                    Text("$tray",
                        style: const TextStyle(fontWeight: FontWeight.bold)),
                  ],
                ),

                const SizedBox(height: 8),

                /// ❌ HIDE PACKET IN COLLECTION
                if (!isCollection) ...[
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Row(
                        children: [
                          Icon(Icons.local_mall, size: 18,
                              color: (isDelivered || isCurrent)
                                  ? Colors.green
                                  : Colors.grey),
                          const SizedBox(width: 6),
                          const Text("Packet"),
                        ],
                      ),
                      Text("$packet",
                          style: const TextStyle(fontWeight: FontWeight.bold)),
                    ],
                  ),
                  const SizedBox(height: 8),
                ],

                /// TUB
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(
                      children: [
                        Icon(Icons.kitchen, size: 18,
                            color: (isDelivered || isCurrent)
                                ? Colors.purple
                                : Colors.grey),
                        const SizedBox(width: 6),
                        const Text("Tub"),
                      ],
                    ),
                    Text("$tub",
                        style: const TextStyle(fontWeight: FontWeight.bold)),
                  ],
                ),

                /// ✅ NEW REMAINING LINE
                if (isCollection &&
                    remainingTray != null &&
                    remainingTub != null) ...[
                  const SizedBox(height: 6),
                  Text(
                    "Remaining: $remainingTray trays, $remainingTub tubs",
                    style: const TextStyle(
                      fontSize: 12,
                      color: Colors.grey,
                    ),
                  ),
                ],
              ],
            ),

            const SizedBox(height: 18),

            /// STATUS (UNCHANGED POSITION)
            Row(
              children: [
                Container(
                  height: 24,
                  padding: const EdgeInsets.symmetric(horizontal: 12),
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    color: getStatusColor().withOpacity(0.15),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Text(
                    getStatusText(),
                    style: TextStyle(
                      color: getStatusColor(),
                      fontWeight: FontWeight.bold,
                      fontSize: 14,
                    ),
                  ),
                ),

                const Spacer(),

                GestureDetector(
                  onTap: isCurrent || isDelivered ? controller.openMap : null,
                  child: Container(
                    height: 30,
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                      color: getStatusColor().withOpacity(0.2),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.directions, size: 18, color: getStatusColor()),
                        const SizedBox(width: 6),
                        Text(
                          "Directions",
                          style: TextStyle(
                            color: getStatusColor(),
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            )
          ],
        ),
      ),
    );
  }
}
