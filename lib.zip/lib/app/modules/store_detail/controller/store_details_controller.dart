import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../api/api_service.dart';
import '../../../models/delivery_model.dart';
import '../../delivery/controllers/delivery_controller.dart';

class StoreDetailsController extends GetxController {
  final ApiService api = Get.find<ApiService>();
  final DeliveryController deliveryController = Get.find();
  
  final _store = Rxn<DeliveryModel>();
  DeliveryModel? get store => _store.value;
  
  final isLoading = false.obs;
  final TextEditingController collectedTraysController =
      TextEditingController();

  @override
  void onInit() {
    super.onInit();
    final initialStore = Get.arguments as DeliveryModel;
    _store.value = initialStore;

    collectedTraysController.text = "0";
    fetchBoothProductDetails();
  }

  Future<void> fetchBoothProductDetails() async {
    if (store == null) return;
    try {
      isLoading.value = true;
      final List<dynamic> data =
          await api.getBoothDetails(deliveryController.tripId, store!.boothId);

      final products =
          data.map((json) => DeliveryProductModel.fromJson(json)).toList();

      // Update the local store with fetched products
      _store.value = store!.copyWith(products: products);
    } catch (e) {
      debugPrint("Error fetching booth details: $e");
    } finally {
      isLoading.value = false;
    }
  }

  @override
  void onClose() {
    // Note: We don't dispose collectedTraysController here because GetX might 
    // reuse the instance or the view might still access it during transitions,
    // which causes the "used after being disposed" error.
    super.onClose();
  }

  Future<void> markDelivered() async {
    if (deliveryController.isLoading.value || store == null) return;
    try {
      await deliveryController.markDelivered(store!);
    } catch (e) {
      Get.snackbar("Error", e.toString());
    }
  }

  Future<void> markCollected() async {
    if (deliveryController.isLoading.value || store == null) return;

    final input = collectedTraysController.text.trim();
    final int collectedCount = int.tryParse(input) ?? 0;

    // Prioritize totalTrays (today's delivery) as the expected return.
    // Fallback to remainingTrays (residue) if totalTrays is 0 (collection-only).
    final int expectedCount = (store!.totalTrays > 0)
        ? store!.totalTrays
        : store!.remainingTrays;

    // Strict validation: Must match expected or be 0
    if (collectedCount != expectedCount && collectedCount != 0) {
      Get.snackbar(
        "Invalid Count",
        "You must collect either all ($expectedCount) or 0 trays.",
        backgroundColor: Colors.red.shade100,
        colorText: Colors.red.shade900,
      );
      return;
    }

    try {
      await deliveryController.markCollected(
        store!,
        collectedCount,
      );
    } catch (e) {
      Get.snackbar("Error", e.toString());
    }
  }

  void openMap() {
    if (store != null) {
      deliveryController.openMap(store!.address);
    }
  }
}
