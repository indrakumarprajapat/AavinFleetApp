import 'package:flutter/material.dart';
/*
class MilkClipper extends CustomClipper<Path>{
  @override
  Path getClip(Size size) {
    Path path = Path();

    path.lineTo(0, size.height * 0.7);

    path.quadraticBezierTo(
        size.width * 0.25,
        size.height,
        size.width * 0.45,
        size.height * 0.7);

    path.quadraticBezierTo(
      size.width * 0.25,
      size.height,
      size.width * 0.85,
      size.height * 0.75,);

    path.quadraticBezierTo(
        size.width * 0.95,
        size.height,
        size.width,
        size.height * 0.7);

    path.lineTo(size.width, 0);
    path.close();

    return path;
  }

  @override
  bool shouldReclip(CustomClipper<Path> oldClipper){
    return false;
  }
}

 */
import 'package:flutter/material.dart';

class MilkClipper extends CustomClipper<Path> {
  @override
  Path getClip(Size size) {
    var path = Path();
    path.lineTo(0, size.height - 30);
    path.quadraticBezierTo(
        size.width * 0.25, size.height, size.width * 0.5, size.height - 20);
    path.quadraticBezierTo(
        size.width * 0.75, size.height - 40, size.width, size.height - 60);
    path.lineTo(size.width, 0);
    path.close();
    return path;
  }

  @override
  bool shouldReclip(CustomClipper<Path> oldClipper) => false;
}
