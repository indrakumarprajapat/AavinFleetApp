enum DeliveryStatus {
  delivered,
  delivering,
  pending,
}

class ProductModel {
  String name;
  int trays;
  int packets;
  int tubs;

  ProductModel({
    required this.name,
    required this.trays,
    required this.packets,
    required this.tubs,
  });
}

class DeliveryModel {
  String number;
  String storeName;
  String address;
  DeliveryStatus status;
  List<ProductModel> products;

  DeliveryModel({
    required this.number,
    required this.storeName,
    required this.address,
    required this.status,
    required this.products,
  });
}
