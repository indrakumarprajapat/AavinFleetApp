import 'dart:io';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../controllers/delivery_controller.dart';
import '../models/delivery_model.dart';
import '../widgets/milk_clipper.dart';

class StoreDetailsScreen extends GetView<DeliveryController> {
  const StoreDetailsScreen({super.key});

  @override
  Widget build(BuildContext context) {

    final DeliveryModel? store = Get.arguments;

    if (store == null) {
      return const Scaffold(
        body: Center(child: Text("Store data not found")),
      );
    }

    /// TOTAL CALCULATIONS
    final int totalTrays =
    store.products.fold(0, (sum, item) => sum + item.trays);

    final int totalPackets =
    store.products.fold(0, (sum, item) => sum + item.packets);

    final int totalTubs =
    store.products.fold(0, (sum, item) => sum + item.tubs);

    return Scaffold(
      backgroundColor: Colors.white,

      body: SingleChildScrollView(
        child: Column(
          children: [

            /// HEADER
            Stack(
              children: [
                ClipPath(
                  clipper: MilkClipper(),
                  child: Container(
                    height: 200,
                    width: double.infinity,
                    color: const Color(0xff1BA6C8),
                  ),
                ),

                Positioned(
                  top: 70,
                  left: 0,
                  right: 0,
                  child: Image.asset(
                    "assets/images/aavin_logo.jpeg",
                    height: 50,
                  ),
                ),
              ],
            ),

            const SizedBox(height: 20),

            /// STORE CARD
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Card(
                elevation: 2,
                color: Colors.white,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16),
                  side: const BorderSide(color: Colors.blue),
                ),
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Row(
                    children: [

                      Container(
                        height: 70,
                        width: 70,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(12),
                          color: Colors.blue.shade50,
                        ),
                        child: const Icon(
                          Icons.store,
                          size: 35,
                          color: Colors.blue,
                        ),
                      ),

                      const SizedBox(width: 15),

                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [

                            Text(
                              store.storeName,
                              style: const TextStyle(
                                fontSize: 22,
                                fontWeight: FontWeight.bold,
                              ),
                            ),

                            const SizedBox(height: 4),

                            Text(
                              store.address,
                              style: const TextStyle(color: Colors.grey),
                            ),
                          ],
                        ),
                      ),

                      Text("ID: ${store.number}")
                    ],
                  ),
                ),
              ),
            ),

            const SizedBox(height: 25),

            /// PRODUCT HEADER
            const Padding(
              padding: EdgeInsets.symmetric(horizontal: 16),
              child: Row(
                children: [

                  Expanded(
                    flex: 3,
                    child: Text(
                      "Item",
                      style: TextStyle(fontWeight: FontWeight.bold),
                    ),
                  ),

                  Expanded(
                    child: Text(
                      "Tray",
                      textAlign: TextAlign.center,
                      style: TextStyle(fontWeight: FontWeight.bold),
                    ),
                  ),

                  Expanded(
                    child: Text(
                      "Packet",
                      textAlign: TextAlign.center,
                      style: TextStyle(fontWeight: FontWeight.bold),
                    ),
                  ),

                  Expanded(
                    child: Text(
                      "Tub",
                      textAlign: TextAlign.center,
                      style: TextStyle(fontWeight: FontWeight.bold),
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 10),

            /// PRODUCT LIST
            ...store.products.map((product) {
              return Padding(
                padding:
                const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                child: Row(
                  children: [

                    Expanded(
                      flex: 3,
                      child: Text(product.name),
                    ),

                    Expanded(
                      child: Text(
                        "${product.trays}",
                        textAlign: TextAlign.center,
                      ),
                    ),

                    Expanded(
                      child: Text(
                        "${product.packets}",
                        textAlign: TextAlign.center,
                      ),
                    ),

                    Expanded(
                      child: Text(
                        "${product.tubs}",
                        textAlign: TextAlign.center,
                      ),
                    ),
                  ],
                ),
              );
            }),

            const SizedBox(height: 10),

            /// TOTAL ROW
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Row(
                children: [

                  const Expanded(
                    flex: 3,
                    child: Text(
                      "Total",
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 16,
                      ),
                    ),
                  ),

                  Expanded(
                    child: Text(
                      "$totalTrays",
                      textAlign: TextAlign.center,
                      style: const TextStyle(fontWeight: FontWeight.bold),
                    ),
                  ),

                  Expanded(
                    child: Text(
                      "$totalPackets",
                      textAlign: TextAlign.center,
                      style: const TextStyle(fontWeight: FontWeight.bold),
                    ),
                  ),

                  Expanded(
                    child: Text(
                      "$totalTubs",
                      textAlign: TextAlign.center,
                      style: const TextStyle(fontWeight: FontWeight.bold),
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 30),

            /// GET DIRECTIONS BUTTON
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.blue,
                  foregroundColor: Colors.white,
                  minimumSize: const Size(double.infinity, 50),
                ),
                onPressed: controller.openMap,
                child: const Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [

                    Text(
                      "Get Directions",
                      style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                      ),
                    ),

                    SizedBox(width: 8),

                    Icon(
                      Icons.my_location_sharp,
                      size: 24,
                    ),
                  ],
                ),
              ),
            ),

            const SizedBox(height: 15),

            /// MARK DELIVERED BUTTON
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: ElevatedButton.icon(
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.green,
                  foregroundColor: Colors.white,
                  minimumSize: const Size(double.infinity, 50),
                ),

                label: const Text(
                  "Mark Delivered",
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                  ),),
                onPressed: () {
                  controller.markDelivered(store);
                  Get.back();
                },
              ),
            ),

            const SizedBox(height: 40),
          ],
        ),
      ),
    );
  }
}
