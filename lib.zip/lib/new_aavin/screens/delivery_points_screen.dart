import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../controllers/delivery_controller.dart';
import '../widgets/delivery_card.dart';
import 'package:aavin/new_aavin/widgets/milk_clipper.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:geolocator/geolocator.dart';

class DeliveryPointsScreen extends GetView<DeliveryController> {
  const DeliveryPointsScreen({super.key});

  @override
  Widget build(BuildContext context) {

    return Scaffold(
      backgroundColor: Colors.grey[100],

      body: Column(
        children: [

          /// BLUE HEADER
          Stack(
            children: [
              ClipPath(
                clipper: MilkClipper(),
                child: Container(
                  height: 200,
                  width: double.infinity,
                  color: const Color(0xff1BA6C8),
                ),
              ),

              Positioned(
                top: 70,
                left: 0,
                right: 0,
                child: Image.asset(
                  "assets/images/aavin_logo.jpeg",
                  height: 50,
                ),
              ),
            ],
          ),

          const SizedBox(height: 16),

          /// HELLO + VEHICLE ROW
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),

            child: Obx(
                  () => Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [

                  RichText(
                    text: TextSpan(
                      children: [
                        const TextSpan(
                          text: "Hello, ",
                          style: TextStyle(
                            fontSize: 18,
                            color: Colors.grey,
                          ),
                        ),

                        TextSpan(
                          text: controller.name.value,
                          style: const TextStyle(
                            fontSize: 24,
                            fontWeight: FontWeight.bold,
                            color: Colors.black,
                          ),
                        ),
                      ],
                    ),
                  ),

                  Row(
                    children: [
                      const Icon(
                        Icons.local_shipping,
                        color: Colors.grey,
                        size: 18,
                      ),

                      const SizedBox(width: 6),

                      Text(
                        controller.vehicleNumber.value,
                        style: const TextStyle(
                          color: Colors.grey,
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),

          const SizedBox(height: 15),

          /// TITLE + MAP BUTTON
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),

            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,

              children: [

                const Text(
                  "Scheduled Deliveries",
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: Colors.blue,
                  ),
                ),

                TextButton.icon(
                  onPressed: () async {

                    Position position =
                    await Geolocator.getCurrentPosition(
                      desiredAccuracy: LocationAccuracy.high,
                    );

                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => DeliveryMapScreen(
                          currentPosition:
                          LatLng(position.latitude, position.longitude),
                        ),
                      ),
                    );
                  },

                  icon: const Icon(Icons.place_outlined,
                      color: Colors.black),

                  label: const Text(
                    "View Map",
                    style: TextStyle(
                      color: Colors.black,
                      decoration: TextDecoration.underline,
                    ),
                  ),
                ),
              ],
            ),
          ),

          const SizedBox(height: 10),

          /// DELIVERY LIST
          Expanded(
            child: Obx(
                  () => ListView.builder(
                padding: const EdgeInsets.symmetric(horizontal: 20),

                itemCount: controller.deliveries.length,

                itemBuilder: (context, index) {

                  final delivery = controller.deliveries[index];

                  /// CALCULATE TOTALS
                  final trayTotal =
                  delivery.products.fold(0, (sum, p) => sum + p.trays);

                  final packetTotal =
                  delivery.products.fold(0, (sum, p) => sum + p.packets);

                  final tubTotal =
                  delivery.products.fold(0, (sum, p) => sum + p.tubs);

                  return Padding(
                    padding: const EdgeInsets.only(bottom: 15),

                    child: DeliveryCard(
                      number: delivery.number,
                      storeName: delivery.storeName,
                      address: delivery.address,
                      tray: trayTotal,
                      packet: packetTotal,
                      tub: tubTotal,
                      status: delivery.status,

                    ),
                  );
                },
              ),
            ),
          ),
        ],
      ),
    );
  }
}

/// MAP SCREEN
class DeliveryMapScreen extends StatelessWidget {

  final LatLng currentPosition;

  const DeliveryMapScreen({
    super.key,
    required this.currentPosition,
  });

  @override
  Widget build(BuildContext context) {

    return Scaffold(
      appBar: AppBar(title: const Text('Delivery Map')),

      body: GoogleMap(
        initialCameraPosition: CameraPosition(
          target: currentPosition,
          zoom: 15,
        ),

        myLocationEnabled: true,
        myLocationButtonEnabled: true,
      ),
    );
  }
}
