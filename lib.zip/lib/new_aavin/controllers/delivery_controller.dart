import 'package:get/get.dart';
import 'package:url_launcher/url_launcher.dart';
import '../models/delivery_model.dart';

class DeliveryController extends GetxController {

  var name = "Rajesh Kumar".obs;
  var vehicleNumber = "TN22CB2871".obs;

  var deliveries = <DeliveryModel>[

    DeliveryModel(
      number: "01",
      storeName: "Balaji Stores",
      address: "No.21 AA Block 3rd St, Anna Nagar",

      status: DeliveryStatus.delivered,
      products: [
        ProductModel(name: "Milk (250ml)", trays: 8, packets: 12, tubs: 0),
        ProductModel(name: "Milk (500ml)", trays: 10, packets: 9, tubs: 0),
        ProductModel(name: "Curd (500ml)", trays: 4, packets: 5, tubs: 4),
      ],
    ),

    DeliveryModel(
      number: "02",
      storeName: "Sivanesh Stores",
      address: "No.21 AA Block 3rd St, Anna Nagar",

      status: DeliveryStatus.delivering,
      products: [
        ProductModel(name: "Milk (250ml)", trays: 6, packets: 9, tubs: 0),
        ProductModel(name: "Milk (500ml)", trays: 8, packets: 0, tubs: 4),
        ProductModel(name: "Curd (500ml)", trays: 2, packets: 0, tubs: 5),
      ],
    ),

    DeliveryModel(
      number: "03",
      storeName: "Kishore Stall",
      address: "No.21 AA Block 3rd St, Anna Nagar",

      status: DeliveryStatus.pending,
      products: [
        ProductModel(name: "Milk (250ml)", trays: 5, packets: 6, tubs: 0),
        ProductModel(name: "Milk (500ml)", trays: 6, packets: 3, tubs: 0),
      ],
    ),

    DeliveryModel(
      number: "04",
      storeName: "Murugan Stores",
      address: "No.21 AA Block 3rd St, Anna Nagar",

      status: DeliveryStatus.pending,
      products: [
        ProductModel(name: "Milk (250ml)", trays: 7, packets: 10, tubs: 2),
        ProductModel(name: "Milk (500ml)", trays: 9, packets: 0, tubs: 0),
        ProductModel(name: "Curd (500ml)", trays: 3, packets: 6, tubs: 0),
      ],
    ),

    DeliveryModel(
      number: "05",
      storeName: "Lakshmi Dairy Store",
      address: "12 Market Road, T. Nagar",


      status: DeliveryStatus.pending,
      products: [
        ProductModel(name: "Milk (250ml)", trays: 5, packets: 8, tubs: 1),
        ProductModel(name: "Milk (500ml)", trays: 7, packets: 0, tubs: 0),
        ProductModel(name: "Curd (500ml)", trays: 4, packets: 5, tubs: 0),
      ],
    ),

    DeliveryModel(
      number: "06",
      storeName: "Sri Balaji Milk Center",
      address: "45 Gandhi Road, Velachery",

      status: DeliveryStatus.pending,
      products: [
        ProductModel(name: "Milk (250ml)", trays: 8, packets: 12, tubs: 2),
        ProductModel(name: "Milk (500ml)", trays: 6, packets: 0, tubs: 0),
        ProductModel(name: "Curd (500ml)", trays: 5, packets: 4, tubs: 1),
      ],
    ),

    DeliveryModel(
      number: "07",
      storeName: "Amman Super Store",
      address: "78 East Street, Tambaram",

      status: DeliveryStatus.pending,
      products: [
        ProductModel(name: "Milk (250ml)", trays: 4, packets: 6, tubs: 1),
        ProductModel(name: "Milk (500ml)", trays: 8, packets: 0, tubs: 0),
        ProductModel(name: "Curd (500ml)", trays: 2, packets: 4, tubs: 0),
      ],
    ),

    DeliveryModel(
      number: "08",
      storeName: "New City Mart",
      address: "33 Lake View Road, Adyar",

      status: DeliveryStatus.pending,
      products: [
        ProductModel(name: "Milk (250ml)", trays: 6, packets: 10, tubs: 2),
        ProductModel(name: "Milk (500ml)", trays: 7, packets: 0, tubs: 0),
        ProductModel(name: "Curd (500ml)", trays: 3, packets: 5, tubs: 1),
      ],
    ),

    DeliveryModel(
      number: "09",
      storeName: "Raja Provision Store",
      address: "91 Station Road, Chromepet",
      status: DeliveryStatus.pending,
      products: [
        ProductModel(name: "Milk (250ml)", trays: 5, packets: 7, tubs: 1),
        ProductModel(name: "Milk (500ml)", trays: 6, packets: 0, tubs: 0),
        ProductModel(name: "Curd (500ml)", trays: 4, packets: 3, tubs: 0),
      ],
    ),
  ].obs;

  /// Navigate to Store Details
  void openStoreDetails(DeliveryModel store) {
    Get.toNamed('/store-details', arguments: store);
  }

  /// Open Google Maps
  void openMap() async {

    final url = Uri.parse(
      "https://www.google.com/maps/search/?api=1&query=Anna+Nagar",
    );

    if (await canLaunchUrl(url)) {
      await launchUrl(url);
    }
  }

  /// MARK STORE AS DELIVERED
  void markDelivered(DeliveryModel store) {

    store.status = DeliveryStatus.delivered;

    deliveries.refresh();

    Get.snackbar(
      "Delivery Complete",
      "${store.storeName} marked as delivered",
      snackPosition: SnackPosition.BOTTOM,
    );
  }
}
